import bodyParser from 'body-parser';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import express from 'express';
import { DBConnection } from './config/db.js';
import router from './routes/user.js';
dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

app.use(bodyParser.json());
app.use(cookieParser());

app.use('/auth', router);

DBConnection();

app.listen(PORT, () => {
  console.log(`The server is running on ${PORT}`);
});